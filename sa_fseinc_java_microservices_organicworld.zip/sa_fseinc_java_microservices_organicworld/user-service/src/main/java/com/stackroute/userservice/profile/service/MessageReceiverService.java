package com.stackroute.userservice.profile.service;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;

import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.stackroute.userservice.errorhandling.exception.CustomerNotFoundException;
import com.stackroute.userservice.profile.dto.CartProductDto;
import com.stackroute.userservice.profile.dto.OrderDto;
import com.stackroute.userservice.profile.model.Address;
import com.stackroute.userservice.profile.model.CartProduct;
import com.stackroute.userservice.profile.model.Order;

/**
 * MessageProducerService class should be used to receive messages from Kafka Topic
 * **TODO**
 * Annotate this class to create a bean of type "Service"
 */

@Service
public class MessageReceiverService {
    /**
     * **TODO**
     * Create a slf4j Logger for logging messages to standard output
     */


    private final CustomerService customerService;
    private final ModelMapper modelMapper;

    private final CountDownLatch latch = new CountDownLatch(1);

    @Autowired
    public MessageReceiverService(CustomerService customerService, ModelMapper modelMapper) {
        this.customerService = customerService;
        this.modelMapper = modelMapper;
    }

    public CountDownLatch getLatch() {
        return latch;
    }

    /**
     * TODO**
     * Create a method receive(OrderDto message)
     * to receive order details message from Kafka topic
     * Use KafkaListener annotation to achieve the same
     * On receipt of the message, count down the latch value(useful for testing receipt of message)
     * Update the order in the customer Document in MongoDb using the customerService
     * Log error messages in case of failure, log informational with message deatils
     * when message is successfully received
     */
    @KafkaListener(topics = "orders", groupId = "group-id")
    public OrderDto receive(OrderDto message) {
    	Order order = convertToOrderEntity(message);
    	
    	System.out.println("@@@@@@@@@@@@ "+order.getOrderId());
    	
    	try {
			customerService.updateCustomerOrder(order);
			CountDownLatch countDownLatch = getLatch();
			countDownLatch.countDown();
		} catch (CustomerNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}    	
    	return message;
    }

    /**
     * TODO**pass
     * Complete the method to convert OrderDTO in to Order Entity
     */
    Order convertToOrderEntity(OrderDto orderDto) {
    	Order order = new Order();
    	modelMapper.map(orderDto, order);
    	
    	
		/*
		 * Order order = new Order(); order.setCustomerId(orderDto.getCustomerId());
		 * Address daddress = new Address(); Address baddress = new Address();
		 * BeanUtils.copyProperties(orderDto.getDeliveryAddress(), daddress);
		 * BeanUtils.copyProperties(orderDto.getBillingAddress(), baddress);
		 * order.setBillingAddress(baddress); order.setDeliveryAddress(daddress);
		 * order.setBillingDate(orderDto.getBillingDate());
		 * 
		 * java.util.List<CartProduct> cartProducts = new ArrayList<CartProduct>();
		 * 
		 * for(CartProductDto productDto : orderDto.getCartProducts()) { CartProduct
		 * cartProduct = new CartProduct(); BeanUtils.copyProperties(productDto,
		 * cartProduct); cartProducts.add(cartProduct); }
		 * 
		 * order.setCartProducts(cartProducts); order.setOrderId(orderDto.getOrderId());
		 * order.setPaymentDetails(orderDto.getPaymentDetails());
		 * order.setStatus(orderDto.getStatus());
		 * order.setTotalBillAmount(orderDto.getTotalBillAmount());
		 */
    	
        return order;
    }
}
