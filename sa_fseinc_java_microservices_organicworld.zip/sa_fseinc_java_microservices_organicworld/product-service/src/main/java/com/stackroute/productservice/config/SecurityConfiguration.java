package com.stackroute.productservice.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.LogoutConfigurer;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.authentication.logout.SimpleUrlLogoutSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

/**
 * This class is to provide the security configuration for the web application
 * which will be used by Admins to manage products
 * <p>
 * **TODO** Add appropriate annotation to this class for creation of Beans
 * Implement interface WebSecurityConfigurerAdapter
 */

@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	/**
	 * TODO** Inject UserDetailsService
	 */
	Logger log = LoggerFactory.getLogger(SecurityConfiguration.class);

	@Autowired
	private UserDetailsService userDetailsService;

	/*
	 * @Bean public AuthenticationProvider authProvider() {
	 * 
	 * DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
	 * provider.setUserDetailsService(userDetailsService);
	 * provider.setPasswordEncoder(passwordEncoder());
	 * 
	 * return provider;
	 * 
	 * }
	 */

	/**
	 * TODO** Override method configure(AuthenticationManagerBuilder auth) and
	 * configure the userDetailsService and passwordEncoder
	 */
	
	  @Override 
	  protected void configure(AuthenticationManagerBuilder auth) throws Exception 
	  { 
		  System.out.println("############# Before auth ##############");
	  
		  DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		  provider.setUserDetailsService(userDetailsService);
		  provider.setPasswordEncoder(passwordEncoder());
		  
		  auth.authenticationProvider(provider);
		  
		  System.out.println("############# After auth ##############"); 
	  }
	 

	/**
	 * TODO** Create a PasswordEncoder bean for encrypting using BCrypt
	 */
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	/**
	 * TODO** Override method configure(HttpSecurity httpSecurity) to achieve the
	 * following Any requests to the Rest endpoints of product service should be
	 * allowed without authentication Any request for using web application by Admin
	 * should be authenticated Use Spring's Default login for Form login login
	 * processing url should be /admin/processlogin After successful login, the page
	 * should be redirected to default url /admin logout should be allowed for all.
	 * logout url should be configured as /admin/logout
	 */

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		
		http.authorizeRequests()
		.antMatchers("/login","/api/*","/admin/logout").permitAll()
		.antMatchers("/**").authenticated()
		.and()
		.formLogin().loginProcessingUrl("/admin/processlogin").defaultSuccessUrl("/admin/products")
		.and()
		.httpBasic();
		
		http.logout().deleteCookies("remove") // logout@delete-cookies
        .invalidateHttpSession(false) // logout@invalidate-session=false (default is true)
        .logoutUrl("/admin/logout").permitAll(); // logout@logout-url (default is /logout)

		http.csrf().disable();  
		
		/*
		 * http .csrf().disable()
		 * .authorizeRequests().antMatchers("/login","/api/*","/admin/logout").permitAll
		 * () .antMatchers("/admin/products").authenticated() .and()
		 * .formLogin().loginProcessingUrl("/admin/processlogin").defaultSuccessUrl(
		 * "/admin/products") .and() .logout().defaultLogoutSuccessHandlerFor(new
		 * LogoutSuccessHandler() {
		 * 
		 * @Override public void onLogoutSuccess(HttpServletRequest request,
		 * HttpServletResponse response, Authentication authentication) throws
		 * IOException, ServletException { // TODO Auto-generated method stub
		 * response.setStatus(HttpServletResponse.SC_OK);
		 * response.sendRedirect("/login"); } }, new RequestMatcher() {
		 * 
		 * @Override public boolean matches(HttpServletRequest request) { // TODO
		 * Auto-generated method stub
		 * if(request.getRequestURI().equalsIgnoreCase("/admin/logout")) { return true;
		 * }else { return false; }
		 * 
		 * } }).logoutSuccessUrl("/login").permitAll();
		 */
		
		
		
		/*
		 * http .csrf().disable()
		 * .authorizeRequests().antMatchers("/login","/api/*").permitAll()
		 * .antMatchers("/admin/products").authenticated() .and()
		 * .formLogin().loginProcessingUrl("/admin/processlogin").defaultSuccessUrl(
		 * "/admin/products") .and() .logout().logoutSuccessHandler(new
		 * LogoutSuccessHandler() {
		 * 
		 * @Override public void onLogoutSuccess(HttpServletRequest request,
		 * HttpServletResponse response, Authentication authentication) throws
		 * IOException, ServletException { // TODO Auto-generated method stub try {
		 * response.setStatus(HttpServletResponse.SC_OK); //redirect to login
		 * response.sendRedirect("/login"); } catch (IOException e) { // TODO
		 * Auto-generated catch block e.printStackTrace(); } } }).permitAll();
		 */
			//logoutRequestMatcher(new AntPathRequestMatcher("/admin/logout")).invalidateHttpSession(true).clearAuthentication(true).permitAll();

		log.info("Config");
		System.out.println("config");

	}

	/**
	 * TODO** Override method configure(WebSecurity web) to ignore the paths of used
	 * by Swagger api like /swagger-resources/**, etc
	 */
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/swagger-resources/**","/swagger-ui.html","/configuration/**");
	}
}
