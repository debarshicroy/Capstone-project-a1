package com.stackroute.productservice.model;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * UserDetailsImpl class represents the UserDetails Object which will
 * be returned by UserDetailsService after authentication
 * <p>
 * ** TODO **
 * Complete the class using the unit tests given.
 * This class should implement UserDetails interface of Spring Security
 * and override all the methods of the interface
 */

public class UserDetailsImpl implements UserDetails, UserDetailsService {

    private String username;
    private String password;
    private boolean active;
    private List<GrantedAuthority> authorities;

    public UserDetailsImpl() {

    }

    /**
     * Parameterized constructor should accept a User object
     * UserDetailsImpl properties should be initialized using the user object passed as parameter
     * ** TODO **
     * Complete the constructor
     */

    public UserDetailsImpl(User user) {
    	this.username = user.getUsername();
    	this.password = user.getPassword();
    	this.active = true;
    	this.authorities = Arrays.asList(new SimpleGrantedAuthority(user.getRole()));
     }

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return authorities;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return password;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return username;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

    /**
     * **TODO**
     * Methods of UserDetailsService to be overridden here
     */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}


}
